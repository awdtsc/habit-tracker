<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

use App\Models\Habit;
use App\Models\HabitTime;
use App\Models\HabitLog;
use App\Models\RemindTask;

/**
 * habits:init-daily
 *
 * 9月方式：
 *  1) 指定日の HabitLog を不足分だけ作成（1日1習慣1レコード、冪等）
 *  2) HabitTimeに基づいて同日の RemindTask（pending, scheduled_at=UTC）を不足分だけ作成（冪等）
 *     - 既存 (habit_time_id, scheduled_at) があれば作らない
 *     - 既存に habit_log_id が無ければ、当日の HabitLog に安全にひも付け（更新）
 *
 * オプション:
 *  --date=YYYY-MM-DD         : 生成対象日（未指定は Asia/Tokyo の今日）
 *  --now="YYYY-MM-DD HH:MM:SS": ログ用の“現在”（動作には影響なし／常に pending 作成）
 *  --habit-id=1 --habit-id=2 : 対象習慣の絞り込み（複数可）
 *  --dry-run                 : 挿入せずシミュレーション表示
 */
class InitDailyHabitLogs extends Command
{
    protected $signature = 'habits:init-daily
                            {--date= : target date YYYY-MM-DD}
                            {--now= : reference time YYYY-MM-DD HH:MM:SS}
                            {--habit-id=* : target habit ids (repeatable)}
                            {--dry-run : simulate without insert/update}';

    protected $description = 'Create daily HabitLog and same-day RemindTask(pending) idempotently (September mode)';

    /** アプリの標準TZ（保存はUTC） */
    private const APP_TZ = 'Asia/Tokyo';

    /** notify_time が無い場合の time_slot 既定通知時刻 */
    private const SLOT_DEFAULT_TIMES = [
        0 => '09:00:00', // anytime
        1 => '08:00:00', // morning
        2 => '12:30:00', // noon
        3 => '18:00:00', // evening
        4 => '22:00:00', // night
    ];

    public function handle(): int
    {
        $tz = self::APP_TZ;

        $nowOption  = $this->option('now');
        $nowTz      = $nowOption ? Carbon::parse($nowOption, $tz) : Carbon::now($tz);

        $dateOption = $this->option('date');
        $targetDateTz = $dateOption
            ? Carbon::parse($dateOption, $tz)->startOfDay()
            : $nowTz->copy()->startOfDay();

        $dryRun      = (bool)$this->option('dry-run');
        $filterIds   = array_values(array_filter((array)$this->option('habit-id'), fn($v) => is_numeric($v)));
        $filterIds   = array_map('intval', $filterIds);

        $this->info("=== habits:init-daily (September mode) ===");
        $this->line("Target Date (TZ={$tz}): " . $targetDateTz->toDateString());
        $this->line("Now         (TZ={$tz}): " . $nowTz->toDateTimeString());
        $this->line("Habit IDs             : " . (empty($filterIds) ? '(ALL planned)' : implode(',', $filterIds)));
        $this->line("Dry-run               : " . ($dryRun ? 'YES' : 'NO'));

        Log::info('habits:init-daily start', [
            'date'     => $targetDateTz->toDateString(),
            'now'      => $nowTz->toDateTimeString(),
            'habit_ids'=> $filterIds,
            'dryRun'   => $dryRun,
        ]);

        $stats = (object)[
            'logs_created'     => 0,
            'logs_existing'    => 0,
            'tasks_created'    => 0,
            'tasks_existing'   => 0,
            'tasks_linked'     => 0, // 既存taskに habit_log_id を安全に追記できた数
            'skipped_notplanned'=> 0,
            'skipped_notimed'  => 0,
        ];

        // ベースクエリ
        $habitsQ = Habit::query()
            ->when($this->hasCol(Habit::query(), 'deleted_at'), fn($q) => $q->whereNull('deleted_at'))
            ->when($this->hasCol(Habit::query(), 'archived_at'), fn($q) => $q->whereNull('archived_at'))
            ->when($this->hasCol(Habit::query(), 'is_active'),   fn($q) => $q->where('is_active', true))
            ->when($this->hasCol(Habit::query(), 'start_date'),  fn($q) => $q->where('start_date', '<=', $targetDateTz->toDateString()))
            ->when(!empty($filterIds), fn($q) => $q->whereIn('id', $filterIds));

        // チャンクごとに HabitTime をまとめて先読み（N+1回避）
        $habitsQ->chunkById(500, function ($habits) use ($targetDateTz, $tz, $dryRun, $stats) {
            $habitIds = $habits->pluck('id')->all();

            $timesByHabit = HabitTime::query()
                ->whereIn('habit_id', $habitIds)
                ->when($this->hasCol(HabitTime::query(), 'deleted_at'), fn($q) => $q->whereNull('deleted_at'))
                ->get()
                ->groupBy('habit_id');

            /** @var Habit $habit */
            foreach ($habits as $habit) {
                // 対象日が計画日に当たるか（days_of_week 等の緩い判定）
                if (!$this->isPlannedOnDate($habit, $targetDateTz)) {
                    $stats->skipped_notplanned++;
                    continue;
                }

                // 1) HabitLog を（当日分だけ）冪等作成
                [$log, $created] = $this->ensureDailyHabitLog($habit, $targetDateTz, $dryRun);
                $created ? $stats->logs_created++ : $stats->logs_existing++;

                // HabitTime が無ければ通知は作らない
                /** @var \Illuminate\Support\Collection<int,HabitTime> $times */
                $times = $timesByHabit->get($habit->id, collect());
                if ($times->isEmpty()) {
                    $stats->skipped_notimed++;
                    continue;
                }

                // 2) 同日の RemindTask（pending）を各 HabitTime ごとに冪等作成
                foreach ($times as $ht) {
                    $timeStr      = $this->resolveNotifyTimeString($ht);
                    $scheduledTz  = Carbon::parse($targetDateTz->toDateString() . ' ' . $timeStr, $tz);
                    $scheduledUtc = $scheduledTz->copy()->utc();

                    // 既存 task の有無
                    /** @var RemindTask|null $task */
                    $task = RemindTask::query()
                        ->where('habit_time_id', $ht->id)
                        ->where('scheduled_at', $scheduledUtc->toDateTimeString())
                        ->first();

                    if (!$task) {
                        if ($dryRun) {
                            $this->line(sprintf(
                                '[DRY] RemindTask INSERT: habit#%d time#%d at %s(UTC) status=pending log#%s',
                                $habit->id,
                                $ht->id,
                                $scheduledUtc->toDateTimeString(),
                                $log?->id ?? 'null'
                            ));
                            $stats->tasks_created++;
                            continue;
                        }

                        // 新規作成（pending 固定）
                        DB::table((new RemindTask())->getTable())->insert([
                            'user_id'        => $habit->user_id,
                            'habit_id'       => $habit->id,
                            'habit_time_id'  => $ht->id,
                            'habit_log_id'   => $log?->id, // nullも許容
                            'scheduled_at'   => $scheduledUtc->toDateTimeString(),
                            'status'         => 'pending',
                            'created_at'     => now(),
                            'updated_at'     => now(),
                        ]);
                        $stats->tasks_created++;
                        continue;
                    }

                    // 既存があり：habit_log_id が未連携なら安全に追記
                    if (!$dryRun && $task->habit_log_id === null && $log?->id) {
                        RemindTask::query()
                            ->where('id', $task->id)
                            ->update(['habit_log_id' => $log->id, 'updated_at' => now()]);
                        $stats->tasks_linked++;
                    } else {
                        $stats->tasks_existing++;
                    }
                }
            }
        });

        $this->info('------------------------------------------');
        $this->info("HabitLog  created : {$stats->logs_created}");
        $this->info("HabitLog  existed : {$stats->logs_existing}");
        $this->info("RemindTask created: {$stats->tasks_created}");
        $this->info("RemindTask existed: {$stats->tasks_existing}");
        $this->info("RemindTask linked : {$stats->tasks_linked}  (existing tasks bound to daily log)");
        $this->info("Skipped not planned: {$stats->skipped_notplanned}");
        $this->info("Skipped no times  : {$stats->skipped_notimed}");

        Log::info('habits:init-daily done', (array)$stats);

        return Command::SUCCESS;
    }

    /** 当日分 HabitLog を冪等作成（1日1習慣1レコード）。[HabitLog|null, bool created] */
    private function ensureDailyHabitLog(Habit $habit, Carbon $dateTz, bool $dryRun): array
    {
        $date = $dateTz->toDateString();

        /** @var HabitLog|null $existing */
        $existing = HabitLog::query()
            ->where('habit_id', $habit->id)
            ->where('date', $date)
            ->first();

        if ($existing) {
            return [$existing, false];
        }

        if ($dryRun) {
            $this->line(sprintf('[DRY] HabitLog INSERT: habit#%d date=%s status=none', $habit->id, $date));
            return [null, true]; // dry-runでは実体を作らない
        }

        // firstOrCreate でユニーク制約と競合時の再取得を吸収
        $log = HabitLog::firstOrCreate(
            ['habit_id' => $habit->id, 'date' => $date],
            [
                'user_id'  => $habit->user_id,
                'status'   => 'none',
                // time_slot / habit_time_id は 1日1ログ方式では null でOK（存在しない環境も考慮）
                ...($this->hasCol(HabitLog::query(), 'time_slot') ? ['time_slot' => null] : []),
                ...($this->hasCol(HabitLog::query(), 'habit_time_id') ? ['habit_time_id' => null] : []),
            ]
        );

        return [$log, $log->wasRecentlyCreated];
    }

    /** HabitTime→通知時刻（HH:MM:SS）を解決（notify_time優先→slot既定→09:00:00） */
    private function resolveNotifyTimeString(HabitTime $ht): string
    {
        if ($this->hasCol(HabitTime::query(), 'notify_time')) {
            $val = $ht->notify_time;
            if (is_string($val) && ($s = trim($val)) !== '') {
                if (preg_match('/^\d{1,2}:\d{2}(:\d{2})?$/', $s)) {
                    return strlen($s) === 5 ? $s . ':00' : $s;
                }
            }
        }
        $slot = $this->hasCol(HabitTime::query(), 'time_slot') ? (int)$ht->time_slot : null;
        if ($slot !== null && array_key_exists($slot, self::SLOT_DEFAULT_TIMES)) {
            return self::SLOT_DEFAULT_TIMES[$slot];
        }
        return self::SLOT_DEFAULT_TIMES[0];
    }

    /**
     * 指定日がその習慣の“予定日”か緩く判定
     * - days_of_week: JSON配列 / カンマ列 / ビットマスクをサポート
     * - start_date / end_date があれば範囲チェック
     * - 無ければ毎日扱い
     */
    private function isPlannedOnDate(Habit $habit, Carbon $dateTz): bool
    {
        $date = $dateTz->toDateString();

        if ($this->hasCol(Habit::query(), 'start_date') && $habit->start_date) {
            if ($date < $habit->start_date) return false;
        }
        if ($this->hasCol(Habit::query(), 'end_date') && $habit->end_date) {
            if ($date > $habit->end_date) return false;
        }

        $dowField = null;
        if ($this->hasCol(Habit::query(), 'days_of_week')) {
            $dowField = $habit->days_of_week;
        } elseif ($this->hasCol(Habit::query(), 'days')) {
            $dowField = $habit->days;
        }
        if (empty($dowField) && $dowField !== 0) {
            return true;
        }

        $weekday = (int)$dateTz->dayOfWeek; // 0=Sun .. 6=Sat

        // JSON "[1,3,5]"
        if (is_string($dowField) && str_starts_with(trim($dowField), '[')) {
            $arr = json_decode($dowField, true);
            if (is_array($arr)) {
                return in_array($weekday, array_map('intval', $arr), true);
            }
        }

        // "1,3,5"
        if (is_string($dowField) && preg_match('/^\s*\d(?:\s*,\s*\d)*\s*$/', $dowField)) {
            $arr = array_map('intval', array_map('trim', explode(',', $dowField)));
            return in_array($weekday, $arr, true);
        }

        // ビットマスク（1<<0=Sun ... 1<<6=Sat）
        if (is_numeric($dowField)) {
            $mask = (int)$dowField;
            return (($mask >> $weekday) & 1) === 1;
        }

        // 形式不明は毎日扱い
        return true;
    }

    /** テーブルのカラム存在チェック（テーブル単位で結果キャッシュ） */
    private function hasCol($query, string $column): bool
    {
        try {
            $table = $query->getModel()->getTable();
            static $cache = [];
            if (!isset($cache[$table])) {
                $cols = DB::getSchemaBuilder()->getColumnListing($table);
                $cache[$table] = array_flip($cols);
            }
            return isset($cache[$table][$column]);
        } catch (\Throwable $e) {
            return false;
        }
    }
}