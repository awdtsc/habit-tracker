<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PushSubscription extends Model
{
    protected $table = 'push_subscriptions';

    // 迷うくらいなら全部許可（updateOrCreate で morph の列も素直に入る）
    protected $guarded = []; // ← これが一番安全

    public function subscribable()
    {
        return $this->morphTo();
    }
}